package com.example.homeworkgeektech_first;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

public class SecondPage extends AppCompatActivity implements View.OnClickListener {
    ImageView imageView;
    EditText editText;
    Button button;
    Uri selectedImageUri = Uri.parse(String.valueOf(R.drawable.ic_launcher_background));

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second_page);
        id();
    }

    private void id() {
        imageView = findViewById(R.id.image1);
        imageView.setOnClickListener(this);

        editText = findViewById(R.id.editText1);

        button = findViewById(R.id.first_btn1);
        button.setOnClickListener(this);
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @SuppressLint("NonConstantResourceId")
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.image1:
                imageChooser();
                break;
            case R.id.first_btn1:
                String temp = editText.getText().toString();
                if (temp.equals("")) {
                    Toast.makeText(getApplicationContext(), "We sent empty message", Toast.LENGTH_SHORT).show();
                }
                Intent intent = new Intent();
                intent.putExtra("KEY", temp);
                intent.putExtra("KEY_IMAGE", selectedImageUri.toString());
                setResult(RESULT_OK, intent);
                finish();
                break;
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    public void imageChooser() {
        if (Build.VERSION.SDK_INT < 19) {
            Intent intent = new Intent();
            intent.setType("image/*");
            intent.setAction(Intent.ACTION_GET_CONTENT);
            startActivityForResult(Intent.createChooser(intent, "Select Picture"), 200);
        } else {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("image/*");
            startActivityForResult(intent, 200);
        }
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK) {
            if (requestCode == 200) {
                selectedImageUri = data.getData();
                if (null != selectedImageUri) {
                    imageView.setImageURI(selectedImageUri);
                }
            }
        }
    }
}
