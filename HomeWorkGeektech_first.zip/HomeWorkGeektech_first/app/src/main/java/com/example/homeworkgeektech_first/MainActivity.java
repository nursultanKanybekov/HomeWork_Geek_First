package com.example.homeworkgeektech_first;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.Random;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    ImageView photo;
    TextView text;
    Button first, second;
    Intent new_page;
    String temp = null;
    String photo_int = "";

    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        id();
    }

    private void id() {
        photo = findViewById(R.id.image);
        photo.setOnClickListener(this);

        text = findViewById(R.id.text);
        text.setOnClickListener(this);

        first = findViewById(R.id.first_btn);
        first.setOnClickListener(this);

        second = findViewById(R.id.second_btn);
        second.setOnClickListener(this);
    }

    @SuppressLint({"NonConstantResourceId", "SetTextI18n"})
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.image:
                Toast.makeText(getApplicationContext(), "Don't forget I love you", Toast.LENGTH_SHORT).show();
                break;
            case R.id.text:
                text.setText(greeter() + " my friend");
                break;
            case R.id.first_btn:
                new_page = new Intent(this, SecondPage.class);
                startActivityForResult(new_page, 2);
                break;
            case R.id.second_btn:
                sendGmail();
                break;
        }
    }

    private void sendGmail() {
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("message/rfc822");
        i.putExtra(Intent.EXTRA_EMAIL, new String[]{"nurs_kanyb@gmail.com"});
        i.putExtra(Intent.EXTRA_SUBJECT, "My topic");
        i.putExtra(Intent.EXTRA_TEXT, temp);
        if (!photo_int.equals(null) || !photo_int.equals("") || !photo_int.equals(String.valueOf(R.drawable.ic_launcher_background))) {
            i.putExtra(Intent.EXTRA_STREAM, Uri.parse(photo_int));
        }

        try {
            startActivity(Intent.createChooser(i, "Send mail..."));
        } catch (android.content.ActivityNotFoundException ex) {
            Toast.makeText(this, "There are no email clients installed.", Toast.LENGTH_SHORT).show();
        }
    }

    private String greeter() {
        String[] cars = {"Hello ", "Hi ", "How are you ", "Salam "};
        int idx = new Random().nextInt(cars.length);
        return (cars[idx]);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK && requestCode == 2) {
            assert data != null;
            photo_int = data.getStringExtra("KEY_IMAGE");
            System.out.println("----------------------");
            System.out.println(photo_int);
            System.out.println("photo_int");
            System.out.println(" ");
            System.out.println("----------------------");
            temp = data.getStringExtra("KEY");
            text.setText(temp);
            //  photo.setImageResource(photo_int);
            if (photo_int.equals(null) || photo_int.equals("") || photo_int.equals(String.valueOf(R.drawable.ic_launcher_background))) {
                photo.setImageResource(R.drawable.ic_launcher_foreground);
            } else {
                photo.setImageURI(Uri.parse(photo_int));
            }

//            try {
//                assert data != null;
//                final Uri imageUri = data.getData();
//                final InputStream imageStream = getContentResolver().openInputStream(imageUri);
//                final Bitmap selectedImage = BitmapFactory.decodeStream(imageStream);
//                photo.setImageBitmap(selectedImage);
//            } catch (FileNotFoundException e) {
//                e.printStackTrace();
//                Toast.makeText(this, "Something went wrong", Toast.LENGTH_LONG).show();
//            }
        }
//        if (resultCode == RESULT_OK && requestCode == 1) {
//            Intent intent1 = getIntent();
//            text1 = intent1.getStringExtra("KEY");
//            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.fromParts("sms", "+996509020253", null));
//            intent.putExtra("sms_body", text1);
//            startActivity(intent);
        //
        //      }
    }

}